alert('Open the browser console whenever you work on JavaScript')

// 1. If statement
let number = 10;
if (number > 5) {
    console.log('Number is greater than 5');
}

// 2. If-else statement
let age = 18;
if (age >= 18) {
    console.log('You are an adult');
} else {
    console.log('You are a minor');
}

// 3. If-else if-else statement
let score = 75;
if (score >= 90) {
    console.log('Grade: A');
} else if (score >= 80) {
    console.log('Grade: B');
} else if (score >= 70) {
    console.log('Grade: C');
} else {
    console.log('Grade: F');
}

// 4. Switch statement
let day = 'Monday';
switch (day) {
    case 'Monday':
        console.log('Start of the work week');
        break;
    case 'Wednesday':
        console.log('Midweek');
        break;
    case 'Friday':
        console.log('End of the work week');
        break;
    default:
        console.log('Weekend');
        break;
}

// 5. Ternary operator
let isLoggedIn = true;
let greeting = isLoggedIn ? 'Welcome back!' : 'Please log in';
console.log(greeting);

// 💻 Exercises
// Exercises: Level 1
console.log('Exercise 1: Check if a number is positive or negative');
let num = -3;
if (num >= 0) {
    console.log('The number is positive');
} else {
    console.log('The number is negative');
}

// Exercises: Level 2
console.log('Exercise 2: Determine the largest of three numbers');
let num1 = 3, num2 = 7, num3 = 5;
if (num1 > num2 && num1 > num3) {
    console.log('num1 is the largest');
} else if (num2 > num1 && num2 > num3) {
    console.log('num2 is the largest');
} else {
    console.log('num3 is the largest');
}

// Exercises: Level 3
console.log('Exercise 3: Determine if a given year is a leap year');
let year = 2024;
if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
    console.log('Leap year');
} else {
    console.log('Not a leap year');
}
