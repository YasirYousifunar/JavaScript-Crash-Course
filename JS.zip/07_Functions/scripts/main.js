console.log(countries)
alert('Open the console and check if the countries has been loaded')

// ## Functions in JavaScript
// JavaScript functions are blocks of code designed to perform specific tasks. They help in making code modular, reusable, and easier to maintain.

// ### Named Functions
// These are functions that have a name when declared and can be called using their identifier.
function namedFunction() {
    console.log('This is a named function');
}
namedFunction(); // Calling the named function

// ### Anonymous Functions
// These are functions without a name, often assigned to a variable or used as an argument to other functions.
const anonFunction = function () {
    console.log('This is an anonymous function');
};
anonFunction(); // Invoking the anonymous function

// ### Arrow Functions
// Introduced in ES6, arrow functions provide a concise way to write functions.
const arrowFunction = () => {
    console.log('This is an arrow function');
};
arrowFunction(); // Calling the arrow function

// ### Constructor Functions
// Functions used to create objects in JavaScript. They act as templates for creating multiple objects with similar properties.
function Person(name, age) {
    this.name = name;
    this.age = age;
    this.greet = function () {
        console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
    };
}
const yasir = new Person('Yasir', 25);
yasir.greet(); // Outputs: Hello, my name is Yasir and I am 25 years old.

// ### Immediately Invoked Function Expressions (IIFE)
// Functions that are executed as soon as they are defined.
(function () {
    console.log('This is an IIFE');
})();

// ### Higher-Order Functions
// Functions that take other functions as arguments or return them as results.
function higherOrderFunction(callback) {
    callback(); // Invoking the callback function
}
higherOrderFunction(() => {
    console.log('Callback function executed');
});

// ### Generator Functions
// Functions that can be paused and resumed, allowing values to be yielded one at a time.
function* generatorFunction() {
    yield 'First value';
    yield 'Second value';
    yield 'Third value';
}
const gen = generatorFunction();
console.log(gen.next().value); // Outputs: First value
console.log(gen.next().value); // Outputs: Second value

// ### Async Functions
// Functions that use the `async` keyword to handle asynchronous operations with `await`.
async function asyncFunction() {
    const promise = new Promise((resolve) => {
        setTimeout(() => resolve('Async function complete'), 1000);
    });
    const result = await promise; // Awaiting the promise to resolve
    console.log(result); // Outputs: Async function complete
}
asyncFunction();

// ## Additional Concepts Related to Functions

// ### Callback Functions
// A function passed as an argument to another function, to be executed later.
function callbackFunction(message, callback) {
    console.log(message);
    callback();
}
callbackFunction('This is a message', () => {
    console.log('Callback executed');
});

// ### Closures
// A closure is a function that has access to its own scope, the parent scope, and the global scope.
function closureExample() {
    let count = 0; // Enclosed variable
    return function () {
        count++;
        console.log(`Count: ${count}`);
    };
}
const increment = closureExample();
increment(); // Outputs: Count: 1
increment(); // Outputs: Count: 2

// ### Function with Default Parameters
// Functions can have default parameters that are used if no argument is provided.
function greet(name = 'Guest') {
    console.log(`Hello, ${name}`);
}
greet(); // Outputs: Hello, Guest
greet('Yasir'); // Outputs: Hello, Yasir

// ### Function with Unlimited Parameters (Rest Parameters)
function sumAll(...numbers) {
    return numbers.reduce((acc, num) => acc + num, 0);
}
console.log(sumAll(1, 2, 3, 4)); // Outputs: 10

// ### Self-Invoking Functions
// Functions that run automatically without being explicitly called.
(function autoRun() {
    console.log('Self-invoking function executed');
})();
