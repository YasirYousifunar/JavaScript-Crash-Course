console.log(countries)
alert('Open the browser console whenever you work on JavaScript')
alert('Open the console and check if the countries has been loaded')

// 1. How to create an empty array
const emptyArray = [];
console.log('Empty array:', emptyArray);

// 2. How to create an array with values
const arrayWithValues = [1, 2, 3, 4, 5];
console.log('Array with values:', arrayWithValues);

// 3. Creating an array using split
const string = 'JavaScript is fun';
const arrayFromString = string.split(' ');
console.log('Array from string:', arrayFromString);

// 4. Accessing array items using index
console.log('First element:', arrayWithValues[0]);
console.log('Last element:', arrayWithValues[arrayWithValues.length - 1]);

// 5. Modifying array element
arrayWithValues[0] = 10;
console.log('Modified array:', arrayWithValues);

// 6. Methods to manipulate array

// Array Constructor
const arr1 = new Array(5); // Creates an empty array of length 5
console.log('Array constructor:', arr1);

// Creating static values with fill
const filledArray = new Array(5).fill('Hello');
console.log('Array filled with static values:', filledArray);

// Concatenating array using concat
const arr2 = [6, 7, 8];
const concatenatedArray = arrayWithValues.concat(arr2);
console.log('Concatenated array:', concatenatedArray);

// Getting array length
console.log('Array length:', arrayWithValues.length);

// Getting index of an element in array
console.log('Index of 4:', arrayWithValues.indexOf(4));

// Getting last index of an element in array
const arr3 = [1, 2, 3, 1, 2, 1];
console.log('Last index of 1:', arr3.lastIndexOf(1));

// Checking if variable is an array
console.log('Is array:', Array.isArray(arr3));

// Converting array to string
console.log('Array as string:', arr3.toString());

// Joining array elements
console.log('Joined array:', arr3.join(' - '));

// Slice array elements
console.log('Sliced array (2 to 4):', arr3.slice(2, 5));

// Splice method in array (adding/removing elements)
arr3.splice(2, 2, 99, 100); // Removes 2 elements starting from index 2 and adds 99, 100
console.log('Array after splice:', arr3);

// Adding item to an array using push
arr3.push(101);
console.log('Array after push:', arr3);

// Removing the end element using pop
arr3.pop();
console.log('Array after pop:', arr3);

// Removing an element from the beginning
arr3.shift();
console.log('Array after shift:', arr3);

// Adding an element to the beginning
arr3.unshift(50);
console.log('Array after unshift:', arr3);

// Reversing array order
console.log('Reversed array:', arr3.reverse());

// Sorting elements in array
const unsortedArray = [3, 1, 4, 1, 5, 9];
console.log('Sorted array:', unsortedArray.sort());

// Array of arrays
const nestedArray = [[1, 2], [3, 4], [5, 6]];
console.log('Array of arrays:', nestedArray);
console.log('Accessing element from nested array:', nestedArray[1][0]);
