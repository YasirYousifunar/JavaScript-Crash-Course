console.log(countries)
alert('Open the console and check if the countries has been loaded')

// Loops in JavaScript

// Most activities in life involve repetitions. Loops help automate repetitive tasks in programming.
// If you prefer watching videos, check out the video tutorials on loops.


// For loop
// Syntax: for(initialization; condition; increment/decrement) { // code goes here }

for (let i = 0; i <= 5; i++) {
    console.log(i); // Output: 0 1 2 3 4 5
}

for (let i = 5; i >= 0; i--) {
    console.log(i); // Output: 5 4 3 2 1 0
}

for (let i = 0; i <= 5; i++) {
    console.log(`${i} * ${i} = ${i * i}`); // Output: squares from 0 to 5
}

const countries = ['Finland', 'Sweden', 'Denmark', 'Norway', 'Iceland'];
const newArr = [];
for (let i = 0; i < countries.length; i++) {
    newArr.push(countries[i].toUpperCase()); // Converts each country name to uppercase
}

// Output: ["FINLAND", "SWEDEN", "DENMARK", "NORWAY", "ICELAND"]

// Adding all elements in the array
const numbers = [1, 2, 3, 4, 5];
let sum = 0;
for (let i = 0; i < numbers.length; i++) {
    sum += numbers[i]; // Adds each number to sum
}
console.log(sum); // Output: 15

// Creating a new array based on existing array values squared
const newArrSquared = [];
for (let i = 0; i < numbers.length; i++) {
    newArrSquared.push(numbers[i] ** 2); // Squares each number
}
console.log(newArrSquared); // Output: [1, 4, 9, 16, 25]


// While loop
let i = 0;
while (i <= 5) {
    console.log(i); // Output: 0 1 2 3 4 5
    i++;
}

// Do while loop
let j = 0;
do {
    console.log(j); // Output: 0 1 2 3 4 5
    j++;
} while (j <= 5);


// For of loop
const numbersArray = [1, 2, 3, 4, 5];
for (const num of numbersArray) {
    console.log(num); // Output: 1 2 3 4 5
}

// Using for of to print squares
for (const num of numbersArray) {
    console.log(num * num); // Output: 1 4 9 16 25
}

// Adding all numbers using for of
let total = 0;
for (const num of numbersArray) {
    total += num; // Adds each number to total
}
console.log(total); // Output: 15

// Looping through web technologies
const webTechs = ['HTML', 'CSS', 'JavaScript', 'React', 'Redux', 'Node', 'MongoDB'];
for (const tech of webTechs) {
    console.log(tech.toUpperCase()); // Output: Each tech in uppercase
}

// Looping through countries
const countryList = ['Finland', 'Sweden', 'Norway', 'Denmark', 'Iceland'];
const upperCaseCountries = [];
for (const country of countryList) {
    upperCaseCountries.push(country.toUpperCase()); // Converts each country to uppercase
}
console.log(upperCaseCountries); // Output: ["FINLAND", "SWEDEN", "NORWAY", "DENMARK", "ICELAND"]


// For of with entries
const entriesArray = ['A', 'B', 'C'];
for (const [index, value] of entriesArray.entries()) {
    console.log(`Index: ${index}, Value: ${value}`); // Output: Index and corresponding value
}

// forEach method
numbersArray.forEach((num, index) => {
    console.log(`Index: ${index}, Value: ${num}`); // Output: Index and value using forEach
});

// Break statement
for (let i = 0; i <= 5; i++) {
    if (i == 3) {
        break; // Breaks the loop when i equals 3
    }
    console.log(i); // Output: 0 1 2
}

// Continue statement
for (let i = 0; i <= 5; i++) {
    if (i == 3) {
        continue; // Skips the iteration when i equals 3
    }
    console.log(i); // Output: 0 1 2 4 5
}


// Exercises: Day 6

// Level 1 Exercises
// 1. Iterate from 0 to 10 using a for loop
for (let i = 0; i <= 10; i++) {
    console.log(i); // Output: 0 to 10
}

// 2. Iterate from 10 to 0 using a for loop
for (let i = 10; i >= 0; i--) {
    console.log(i); // Output: 10 to 0
}

// 3. Iterate from 0 to n (where n = 5) using a for loop
const n = 5;
for (let i = 0; i <= n; i++) {
    console.log(i); // Output: 0 to 5
}

// 4. Print a pattern using loops
for (let i = 0; i < 7; i++) {
    console.log('#'.repeat(i + 1)); // Creates a right-aligned triangle pattern
}

// 5. Print multiplication of numbers from 0 to 10
for (let i = 0; i <= 10; i++) {
    console.log(`${i} x ${i} = ${i * i}`); // Output: Multiplication table of squares
}

// 6. Print i, i^2, and i^3
console.log('i\ti^2\ti^3');
for (let i = 0; i <= 10; i++) {
    console.log(`${i}\t${i ** 2}\t${i ** 3}`); // Output: Table of i, i^2, i^3
}

// 7. Print even numbers from 0 to 100
for (let i = 0; i <= 100; i += 2) {
    console.log(i); // Output: Even numbers from 0 to 100
}

// 8. Print odd numbers from 0 to 100
for (let i = 1; i <= 100; i += 2) {
    console.log(i); // Output: Odd numbers from 0 to 100
}

// 9. Print prime numbers from 0 to 100
for (let num = 2; num <= 100; num++) {
    let isPrime = true;
    for (let i = 2; i <= Math.sqrt(num); i++) {
        if (num % i === 0) {
            isPrime = false;
            break;
        }
    }
    if (isPrime) {
        console.log(num); // Output: Prime numbers from 0 to 100
    }
}

// 10. Print sum of all numbers from 0 to 100
let totalSum = 0;
for (let i = 0; i <= 100; i++) {
    totalSum += i; // Adds each number to totalSum
}
console.log(`The sum of all numbers from 0 to 100 is ${totalSum}.`); // Output: 5050

// 11. Print sum of all evens and odds from 0 to 100
let sumEvens = 0;
let sumOdds = 0;
for (let i = 0; i <= 100; i++) {
    if (i % 2 === 0) {
        sumEvens += i; // Adds even numbers to sumEvens
    } else {
        sumOdds += i; // Adds odd numbers to sumOdds
    }
}
console.log(`The sum of all evens from 0 to 100 is ${sumEvens}. And the sum of all odds from 0 to 100 is ${sumOdds}.`);

// 12. Print sum of all evens and odds as an array
console.log([sumEvens, sumOdds]); // Output: [2550, 2500]


// Level 2 Exercises
// 1. Create a pattern using nested loops
for (let i = 0; i <= 5; i++) {
    console.log((i.toString() + ' ').repeat(6 - i).trim()); // Output: Pattern with decreasing numbers
}

// 2. Create a pyramid pattern
for (let i = 0; i <= 5; i++) {
    console.log(' '.repeat(5 - i) + [...Array(i).keys()].map(x => x + 1).join('') + [...Array(i).keys()].reverse().map(x => x + 1).join('')); // Output: Pyramid pattern
}

// 3. Create a multiplication table
for (let i = 1; i <= 10; i++) {
    for (let j = 1; j <= 10; j++) {
        console.log(`${i} x ${j} = ${i * j}`); // Output: Multiplication table from 1 to 10
    }
}
