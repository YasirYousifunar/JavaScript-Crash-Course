// Assignment Operators
let x = 10; // Simple assignment
x += 5; // x = x + 5; now x = 15
x -= 3; // x = x - 3; now x = 12
x *= 2; // x = x * 2; now x = 24
x /= 4; // x = x / 4; now x = 6
x %= 5; // x = x % 5; now x = 1
x **= 3; // x = x ** 3; now x = 1^3 = 1

console.log('Assignment Operators Result:', x);

// Arithmetic Operators
let a = 7;
let b = 3;
console.log('Addition:', a + b); // 10
console.log('Subtraction:', a - b); // 4
console.log('Multiplication:', a * b); // 21
console.log('Division:', a / b); // 2.333...
console.log('Modulus:', a % b); // 1
console.log('Exponentiation:', a ** b); // 343 (7^3)

// Comparison Operators
console.log('Equal (==):', a == '7'); // true (loose equality)
console.log('Strict Equal (===):', a === 7); // true (strict equality)
console.log('Not Equal (!=):', a != 3); // true
console.log('Strict Not Equal (!==):', a !== '7'); // true
console.log('Greater than (>):', a > b); // true
console.log('Less than (<):', a < b); // false
console.log('Greater than or equal to (>=):', a >= 7); // true
console.log('Less than or equal to (<=):', a <= 10); // true

// Logical Operators
let isTrue = true;
let isFalse = false;
console.log('Logical AND (&&):', isTrue && isFalse); // false
console.log('Logical OR (||):', isTrue || isFalse); // true
console.log('Logical NOT (!):', !isTrue); // false

// Increment and Decrement Operators
let count = 0;
console.log('Pre-Increment:', ++count); // 1
console.log('Post-Increment:', count++); // 1 (value shown before increment)
console.log('Value after Post-Increment:', count); // 2

console.log('Pre-Decrement:', --count); // 1
console.log('Post-Decrement:', count--); // 1 (value shown before decrement)
console.log('Value after Post-Decrement:', count); // 0

// Ternary Operator
let age = 20;
let ageCheck = age >= 18 ? 'Adult' : 'Minor';
console.log('Ternary Operator Result:', ageCheck); // 'Adult'

// Bitwise Operators
let num1 = 5; // 0101 in binary
let num2 = 3; // 0011 in binary
console.log('Bitwise AND (&):', num1 & num2); // 0001 => 1
console.log('Bitwise OR (|):', num1 | num2); // 0111 => 7
console.log('Bitwise XOR (^):', num1 ^ num2); // 0110 => 6
console.log('Bitwise NOT (~):', ~num1); // Inverts bits => -6
console.log('Left Shift (<<):', num1 << 1); // 1010 => 10
console.log('Right Shift (>>):', num1 >> 1); // 0010 => 2
console.log('Unsigned Right Shift (>>>):', num1 >>> 1); // 0010 => 2

// Type Operators
console.log('Typeof Operator:', typeof num1); // 'number'
console.log('Instanceof Operator:', num1 instanceof Number); // false (primitive type)

// Nullish Coalescing Operator (??)
let undefinedValue = undefined;
let result = undefinedValue ?? 'Default value';
console.log('Nullish Coalescing (??):', result); // 'Default value'

// Optional Chaining Operator (?.)
let user = {
  name: 'John',
  address: {
    city: 'New York',
  },
};
console.log('Optional Chaining:', user?.address?.city); // 'New York'
console.log('Optional Chaining with non-existent property:', user?.contact?.phone); // undefined


// Ternary Operator
let age1 = 20;
let ageCheck1 = age1 >= 18 ? 'Adult' : 'Minor';
console.log('Ternary Operator Result:', ageCheck1); // 'Adult'

// Date Object Operations
let now = new Date();
console.log('Current Date and Time:', now);
console.log('Full Year:', now.getFullYear()); // e.g., 2024
console.log('Month (0-based):', now.getMonth()); // 0 for January, 11 for December
console.log('Date:', now.getDate()); // Day of the month
console.log('Day of the Week (0-6):', now.getDay()); // 0 is Sunday, 6 is Saturday
console.log('Hours:', now.getHours()); // Current hour
console.log('Minutes:', now.getMinutes()); // Current minutes
console.log('Seconds:', now.getSeconds()); // Current seconds

// Operator Precedence Example
let result1 = 3 + 4 * 2; // Multiplication has higher precedence, so result = 3 + (4 * 2) = 11
console.log('Operator Precedence Result:', result1);