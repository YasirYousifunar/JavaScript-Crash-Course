// ## JavaScript Data Types
// JavaScript has various data types that can be classified into two main categories:
// - Primitive Data Types
// - Non-Primitive (Reference) Data Types

// ### Primitive Data Types
// These are immutable and are stored directly in the variable.


// 1. **String**
// Represents text data enclosed in single, double, or backticks.
let name = "Yasir"; // Double quotes
let greeting = 'Hello'; // Single quotes
let templateLiteral = `Welcome, ${name}`; // Template literals with backticks
console.log(name); // Outputs: Yasir
console.log(greeting); // Outputs: Hello
console.log(templateLiteral); // Outputs: Welcome, Yasir


// 2. **Number**
// Represents both integer and floating-point numbers.
let age = 25; // Integer
let temperature = 98.6; // Float
console.log(age); // Outputs: 25
console.log(temperature); // Outputs: 98.6


// 3. **BigInt**
// Used for very large integers, beyond the Number type's safe limit.
let largeNumber = BigInt(123456789012345678901234567890);
console.log(largeNumber); // Outputs: 123456789012345678901234567890n


// 4. **Boolean**
// Represents a logical entity with two values: true or false.
let isActive = true;
let isComplete = false;
console.log(isActive); // Outputs: true
console.log(isComplete); // Outputs: false


// 5. **Undefined**
// Represents a variable that has been declared but not assigned a value.
let uninitialized;
console.log(uninitialized); // Outputs: undefined


// 6. **Null**
// Represents the intentional absence of any object value.
let emptyValue = null;
console.log(emptyValue); // Outputs: null


// 7. **Symbol**
// Used to create unique identifiers, often useful in objects to avoid property conflicts.
let uniqueId = Symbol('id');
let anotherUniqueId = Symbol('id');
console.log(uniqueId === anotherUniqueId); // Outputs: false (Symbols are always unique)


// ### Non-Primitive (Reference) Data Types
// These types are mutable and stored as references. They include objects, arrays, and functions.


// 8. **Object**
// Used to store collections of data in key-value pairs.
let person = {
    name: "Yasir",
    age: 25,
    isStudent: true
};
console.log(person); // Outputs: { name: 'Yasir', age: 25, isStudent: true }


// 9. **Array**
// A special type of object for storing lists of values.
let colors = ['Red', 'Green', 'Blue'];
console.log(colors); // Outputs: ['Red', 'Green', 'Blue']
console.log(colors[0]); // Accesses the first element, Outputs: 'Red'


// 10. **Function**
// A block of code that performs a specific task and can be executed when invoked.
function sayHello() {
    console.log("Hello, World!");
}
sayHello(); // Outputs: Hello, World!


// ### Additional Data Concepts in JavaScript

// - **Dynamic Typing**: JavaScript variables can hold any data type and change types dynamically.
let dynamicVar = 42;  // Initially a Number
dynamicVar = "Now I'm a String";  // Reassigned to String
console.log(dynamicVar); // Outputs: Now I'm a String


// ### Special Values in JavaScript

// - **NaN**: Stands for "Not-a-Number", resulting from invalid or undefined mathematical operations.
let notANumber = "abc" / 4;
console.log(notANumber); // Outputs: NaN

// - **Infinity and -Infinity**: Represent values that are beyond the maximum or minimum limit for numbers.
let infiniteValue = 1 / 0;
let negativeInfiniteValue = -1 / 0;
console.log(infiniteValue); // Outputs: Infinity
console.log(negativeInfiniteValue); // Outputs: -Infinity
