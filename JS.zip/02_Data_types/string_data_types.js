let space = ' ' // an empty space string
let firstName = 'Yasir'
let lastName = 'Yousuf'
let country = 'Pakistan'
let city = 'Hyderabad'
let language = 'JavaScript'
let job = 'Learner'
