// length: The string length method returns the number of characters in a string included empty space. Example:

let js = 'JavaScript'
console.log(js.length)        // 10
let firstName = 'Yasir Yousuf'
console.log(firstName.length) // 8