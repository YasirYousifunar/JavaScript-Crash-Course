// toUpperCase(): this method changes the string to uppercase letters.

let string = 'JavaScript'
console.log(string.toUpperCase())      // JAVASCRIPT
let firstName = 'Yasir'
console.log(firstName.toUpperCase())  // YASIR
let country = 'Pakistan'
console.log(country.toUpperCase())    // PAKISTAN