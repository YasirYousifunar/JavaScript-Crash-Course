// concat(): it takes many substrings and creates concatenation.
// string.concat(substring, substring, substring)
let string = 'Crash'
console.log(string.concat("Course", "Of", "JavaScript")) // CrashCourseOfJavaScript
let country = 'Pak'
console.log(country.concat("istan")) // Pakistan
