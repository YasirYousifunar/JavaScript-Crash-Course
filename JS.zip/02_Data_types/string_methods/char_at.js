// charAt(): Takes index and it returns the value at that index
string.charAt(3)
let string = 'Crash Course Of JavaScript'
console.log(string.charAt(0)) // 3
let lastIndex = string.length - 1
console.log(string.charAt(lastIndex)) // t
