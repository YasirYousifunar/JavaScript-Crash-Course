// charCodeAt(): Takes index and it returns char code(ASCII number) of the value at that index

string.charCodeAt(index)
let string = 'Crash Course Of JavaScript'
console.log(string.charCodeAt(3)) // D ASCII number is 51
let lastIndex = string.length - 1
console.log(string.charCodeAt(lastIndex)) // t ASCII is 116
