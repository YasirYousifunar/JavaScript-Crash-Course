// toLowerCase(): this method changes the string to lowercase letters.
let string = 'JavasCript'
console.log(string.toLowerCase())     // javascript
let firstName = 'Yasir'
console.log(firstName.toLowerCase())  // yasir
let country = 'Finland'
console.log(country.toLowerCase())   // finland