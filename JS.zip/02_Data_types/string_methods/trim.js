//trim(): Removes trailing space in the beginning or the end of a string.
let string = '   30 Days Of JavaScript   '
console.log(string)     // 
console.log(string.trim(' '))  // 
let firstName = '    Yasir Yousuf     '
console.log(firstName)
console.log(firstName.trim())  // 