// replace(): takes to parameter the old substring and new substring.
// string.replace(oldsubstring, newsubstring)

let string = '30 Days Of JavaScript'
console.log(string.replace('JavaScript', 'Python')) // 30 Days Of Python
let country = 'Pakistan'
console.log(country.replace('Pak', 'UzbeK')) // Uzbekistan