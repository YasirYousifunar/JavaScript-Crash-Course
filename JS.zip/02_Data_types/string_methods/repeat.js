// repeat(): it takes a number argument and it returned the repeated version of the string.
// string.repeat(n)
let string = 'love'
console.log(string.repeat(10)) // lovelovelovelovelovelovelovelovelovelove