// the variable values can be accessed from other variable.js file
console.log(firstName, lastName, country, city, age, isMarried) 
console.log(gravity, boilingPoint, PI) // 9.81, 100, 3.14
console.log(name, job, live)